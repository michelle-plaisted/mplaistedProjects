public class MyProgram extends ConsoleProgram
{
    private String box1;
    private String box2;
    private String box3;
    private String box4;
    private String box5;
    private String box6;
    private String box7;
    private String box8;
    private String box9;
    
    private String XsOrOs;
    private String computerPlays;
    private int gameOver;
    
    public void run()
    {
        instructions();
        box1 = " ";
        box2 = " ";
        box3 = " ";
        box4 = " ";
        box5 = " ";
        box6 = " ";
        box7 = " ";
        box8 = " ";
        box9 = " ";
        gameOver = 0;
        while (gameOver < 9)
        {
            userTurn();
            computerTurn();
            makeBoard();
            checkIfDone();
            gameOver += 1;
        }
        //scroll(41);
        //makeBoard();
        //final double pi = hasdjfha;
    }
    
    public void instructions()
    {
        System.out.println("Welcome to Tic Tac Toe!");
        System.out.println("In this game, the goal is to get 3 of your own characters in a row");
        System.out.println("before the computer does.");
        System.out.println("This can be horizontally, vertically, or diagonally.");
        System.out.println("Good luck!");
        System.out.println();



        System.out.println("When you play, enter a number based on what box you want to choose.");
        System.out.println("           |          |          ");
        System.out.println("     1     |    2     |    3     ");
        System.out.println(" __________|__________|__________");
        System.out.println("           |          |          ");
        System.out.println("     4     |    5     |    6     ");
        System.out.println(" __________|__________|__________");
        System.out.println("           |          |          ");
        System.out.println("     7     |    8     |    9     ");
        System.out.println("           |          |          ");
        XsOrOs = readLine ("Do you want to be X's or O's? ");
        if (XsOrOs.equalsIgnoreCase("x"))
        {
            computerPlays = "O";
        }
        else if (XsOrOs.equalsIgnoreCase ("o"))
        {
            computerPlays = "X";
        }
        else
        {
            XsOrOs = readLine ("Please enter either the letter X or O: ");
        }
    }
    public void scroll(int numLines)
    {
        for (int i = 0; i < numLines; i++)
        {
            System.out.println();
        }
    }
    public void makeBoard()
    {
        System.out.println("           |          |          ");
        System.out.println("     " + box1 + "     |    " + box2 + "     |    " + box3 + "     ");
        System.out.println(" __________|__________|__________");
        System.out.println("           |          |          ");
        System.out.println("     " + box4 + "     |    " + box5 + "     |    " + box6 + "     ");
        System.out.println(" __________|__________|__________");
        System.out.println("           |          |          ");
        System.out.println("     " + box7 + "     |    " + box8 + "     |    " + box9 + "     ");
        System.out.println("           |          |          ");
    }
    
    public void userTurn()
    {
        System.out.println();
        int turnChoice = readInt("In what spot number would you like to put an " + XsOrOs + "? ");
        if (turnChoice == 1 && box1.equals (" "))
        {
            box1 = XsOrOs;
        }
        else if (turnChoice == 2 && box2.equals(" "))
        {
            box2 = XsOrOs;
        }
        else if (turnChoice == 3 && box3.equals (" "))
        {
            box3 = XsOrOs;
        }
        else if (turnChoice == 4 && box4.equals (" "))
        {
            box4 = XsOrOs;
        }
        else if (turnChoice == 5 && box5.equals (" "))
        {
            box5 = XsOrOs;
        }
        else if (turnChoice == 6 && box6.equals (" "))
        {
            box6 = XsOrOs;
        }
        else if (turnChoice == 7 && box7.equals (" "))
        {
            box7 = XsOrOs;
        }
        else if (turnChoice == 8 && box8.equals (" "))
        {
            box8 = XsOrOs;
        }
        else if (turnChoice == 9 && box9.equals (" "))
        {
            box9 = XsOrOs;
        }
        else
        {
            System.out.println("Sorry, the computer already took this spot!");
        }
    
    }
    
    public void computerTurn()
    {
        int cturn = (int)(Math.random() * 9) + 1;
        if (cturn == 1) 
        {
            if (box1.equals (" "))
            {
                box1 = computerPlays;
            }
            else
            {
                cturn = (int)(Math.random() * 9) + 1;
            }
        }
        if (cturn == 2) 
        {
            if (box2.equals (" "))
            {
                box2 = computerPlays;
            }
            else
            {
                cturn = (int)(Math.random() * 9) + 1;
            }
        }
        if (cturn == 3) 
        {
            if (box3.equals (" "))
            {
                box3 = computerPlays;
            }
            else
            {
                cturn = (int)(Math.random() * 9) + 1;
            }
        }
        if (cturn == 4) 
        {
            if (box4.equals (" "))
            {
                box4 = computerPlays;
            }
            else
            {
                cturn = (int)(Math.random() * 9) + 1;
            }
        }
        if (cturn == 5) 
        {
            if (box5.equals (" "))
            {
                box5 =  computerPlays;
            }
            else
            {
                cturn = (int)(Math.random() * 9) + 1;
            }
        }
        if (cturn == 6) 
        {
            if (box6.equals (" "))
            {
                box6 = computerPlays;
            }
            else
            {
                cturn = (int)(Math.random() * 9) + 1;
            }
        }
        if (cturn == 7) 
        {
            if (box7.equals (" "))
            {
                box7 = computerPlays;
            }
            else
            {
                cturn = (int)(Math.random() * 9) + 1;
            }
        }
        if (cturn == 8) 
        {
            if (box8.equals (" "))
            {
                box8 = computerPlays;
            }
            else
            {
                cturn = (int)(Math.random() * 9) + 1;
            }
        }
        if (cturn == 9) 
        {
            if (box9.equals (" "))
            {
                box9 = computerPlays;
            }
            else
            {
                cturn = (int)(Math.random() * 9) + 1;
            }
        }
    }
    public void checkIfDone()
    {
        //PLAYER PART
        //Horizontals
        if (box1.equals (XsOrOs) && box2.equals (XsOrOs) && box3.equals (XsOrOs))
        {
            System.out.println("Player wins!");
            gameOver = 10;
        }
        else if (box4.equals (XsOrOs) && box5.equals (XsOrOs) && box6.equals (XsOrOs))
        {
            System.out.println("Player wins!");
            gameOver = 10;
        }
        else if (box7.equals (XsOrOs) && box8.equals (XsOrOs) && box9.equals (XsOrOs))
        {
            System.out.println("Player wins!");
            gameOver = 10;
        }
        //Verticals
        else if (box1.equals (XsOrOs) && box4.equals (XsOrOs) && box7.equals (XsOrOs))
        {
            System.out.println("Player wins!");
            gameOver = 10;
        }
        else if (box2.equals (XsOrOs) && box5.equals (XsOrOs) && box8.equals (XsOrOs))
        {
            System.out.println("Player wins!");
            gameOver = 10;
        }
        else if (box3.equals (XsOrOs) && box6.equals (XsOrOs) && box9.equals (XsOrOs))
        {
            System.out.println("Player wins!");
            gameOver = 10;
        }
        //Diagonals
        else if (box1.equals (XsOrOs) && box5.equals (XsOrOs) && box9.equals (XsOrOs))
        {
            System.out.println("Player wins!");
            gameOver = 10;
        }
        else if (box7.equals (XsOrOs) && box5.equals (XsOrOs) && box3.equals (XsOrOs))
        {
            System.out.println("Player wins!");
            gameOver = 10;
        }
        //COMPUTER PART
        //Horizontals
        else if (box1.equals (computerPlays) && box2.equals (computerPlays) && box3.equals (computerPlays))
        {
            System.out.println("Computer wins!");
            gameOver = 10;
        }
        else if (box4.equals (computerPlays) && box5.equals (computerPlays) && box6.equals (computerPlays))
        {
            System.out.println("Computer wins!");
            gameOver = 10;
        }
        else if (box7.equals (computerPlays) && box8.equals (computerPlays) && box9.equals (computerPlays))
        {
            System.out.println("Computer wins!");
            gameOver = 10;
        }
        //Verticals
        else if (box1.equals (computerPlays) && box4.equals (computerPlays) && box7.equals (computerPlays))
        {
            System.out.println("Player wins!");
            gameOver = 10;
        }
        else if (box2.equals (computerPlays) && box5.equals (computerPlays) && box8.equals (computerPlays))
        {
            System.out.println("Player wins!");
            gameOver = 10;
        }
        else if (box3.equals (computerPlays) && box6.equals (computerPlays) && box9.equals (computerPlays))
        {
            System.out.println("Player wins!");
            gameOver = 10;
        }
        //diagonals
        else if (box1.equals (computerPlays) && box5.equals (computerPlays) && box9.equals (computerPlays))
        {
            System.out.println("Computer wins!");
            gameOver = 10;
        }
        else if (box7.equals (computerPlays) && box5.equals (computerPlays) && box3.equals (computerPlays))
        {
            System.out.println("Computer wins!");
            gameOver = 10;
        }
        
    }
}